"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SimpleContent = /** @class */ (function () {
    function SimpleContent(myId, title, text) {
        this.myId = myId;
        this.title = title;
        this.text = text;
    }
    return SimpleContent;
}());
exports.SimpleContent = SimpleContent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2ltcGxlLWNvbnRlbnQubW9kZWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzaW1wbGUtY29udGVudC5tb2RlbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BO0lBQ0UsdUJBQW1CLElBQVksRUFBUyxLQUFhLEVBQVMsSUFBWTtRQUF2RCxTQUFJLEdBQUosSUFBSSxDQUFRO1FBQVMsVUFBSyxHQUFMLEtBQUssQ0FBUTtRQUFTLFNBQUksR0FBSixJQUFJLENBQVE7SUFBRyxDQUFDO0lBQ2hGLG9CQUFDO0FBQUQsQ0FBQyxBQUZELElBRUM7QUFGWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgSVNpbXBsZUNvbnRlbnRNb2RlbCB7XHJcbiAgbXlJZDogc3RyaW5nO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgdGV4dDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgU2ltcGxlQ29udGVudCBpbXBsZW1lbnRzIElTaW1wbGVDb250ZW50TW9kZWwge1xyXG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBteUlkOiBzdHJpbmcsIHB1YmxpYyB0aXRsZTogc3RyaW5nLCBwdWJsaWMgdGV4dDogc3RyaW5nKSB7fVxyXG59XHJcbiJdfQ==