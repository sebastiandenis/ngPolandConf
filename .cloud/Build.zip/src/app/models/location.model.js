"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Location = /** @class */ (function () {
    function Location(lat, lon) {
        this.lat = lat;
        this.lon = lon;
    }
    return Location;
}());
exports.Location = Location;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYXRpb24ubW9kZWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsb2NhdGlvbi5tb2RlbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUtBO0lBQ0Usa0JBQW1CLEdBQVcsRUFBUyxHQUFXO1FBQS9CLFFBQUcsR0FBSCxHQUFHLENBQVE7UUFBUyxRQUFHLEdBQUgsR0FBRyxDQUFRO0lBQUcsQ0FBQztJQUN4RCxlQUFDO0FBQUQsQ0FBQyxBQUZELElBRUM7QUFGWSw0QkFBUSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgSUxvY2F0aW9uIHtcclxuICBsYXQ6IG51bWJlcjtcclxuICBsb246IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIExvY2F0aW9uIGltcGxlbWVudHMgSUxvY2F0aW9uIHtcclxuICBjb25zdHJ1Y3RvcihwdWJsaWMgbGF0OiBudW1iZXIsIHB1YmxpYyBsb246IG51bWJlcikge31cclxufVxyXG4iXX0=