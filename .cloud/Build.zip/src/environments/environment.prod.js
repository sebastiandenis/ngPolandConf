"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = {
    production: true,
    contentful: {
        spaceId: "87a5voy5in4s",
        token: "b21c9654f0c3a9b02d30e387e6d99c010c5f83e0f83e0b3cb2431dfa5d3b2914"
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52aXJvbm1lbnQucHJvZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImVudmlyb25tZW50LnByb2QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBYSxRQUFBLFdBQVcsR0FBRztJQUN6QixVQUFVLEVBQUUsSUFBSTtJQUNoQixVQUFVLEVBQUU7UUFDVixPQUFPLEVBQUUsY0FBYztRQUN2QixLQUFLLEVBQUUsa0VBQWtFO0tBQzFFO0NBQ0YsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBlbnZpcm9ubWVudCA9IHtcclxuICBwcm9kdWN0aW9uOiB0cnVlLFxyXG4gIGNvbnRlbnRmdWw6IHtcclxuICAgIHNwYWNlSWQ6IFwiODdhNXZveTVpbjRzXCIsXHJcbiAgICB0b2tlbjogXCJiMjFjOTY1NGYwYzNhOWIwMmQzMGUzODdlNmQ5OWMwMTBjNWY4M2UwZjgzZTBiM2NiMjQzMWRmYTVkM2IyOTE0XCJcclxuICB9XHJcbn07XHJcbiJdfQ==