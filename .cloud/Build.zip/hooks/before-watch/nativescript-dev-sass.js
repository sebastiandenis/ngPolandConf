module.exports = require("nativescript-dev-sass/lib/watch.js");
